<?php

declare(strict_types=1);

namespace Grazulex\LaravelArc\Generator;

use Grazulex\LaravelArc\Generator\Fields\ArrayFieldGenerator;
use Grazulex\LaravelArc\Generator\Fields\BooleanFieldGenerator;
use Grazulex\LaravelArc\Generator\Fields\DateFieldGenerator;
use Grazulex\LaravelArc\Generator\Fields\DateTimeFieldGenerator;
use Grazulex\LaravelArc\Generator\Fields\DecimalFieldGenerator;
use Grazulex\LaravelArc\Generator\Fields\EnumFieldGenerator;
use Grazulex\LaravelArc\Generator\Fields\FloatFieldGenerator;
use Grazulex\LaravelArc\Generator\Fields\IdFieldGenerator;
use Grazulex\LaravelArc\Generator\Fields\IntegerFieldGenerator;
use Grazulex\LaravelArc\Generator\Fields\JsonFieldGenerator;
use Grazulex\LaravelArc\Generator\Fields\StringFieldGenerator;
use Grazulex\LaravelArc\Generator\Fields\TextFieldGenerator;
use Grazulex\LaravelArc\Generator\Fields\TimeFieldGenerator;
use Grazulex\LaravelArc\Generator\Fields\UuidFieldGenerator;
use Grazulex\LaravelArc\Generator\Headers\DtoHeaderGenerator;
use Grazulex\LaravelArc\Generator\Headers\ModelHeaderGenerator;
use Grazulex\LaravelArc\Generator\Headers\TableHeaderGenerator;
use Grazulex\LaravelArc\Generator\Options\SoftDeletesOptionGenerator;
use Grazulex\LaravelArc\Generator\Options\TimestampsOptionGenerator;
use Grazulex\LaravelArc\Generator\Relations\BelongsToManyRelationGenerator;
use Grazulex\LaravelArc\Generator\Relations\BelongsToRelationGenerator;
use Grazulex\LaravelArc\Generator\Relations\HasManyRelationGenerator;
use Grazulex\LaravelArc\Generator\Relations\HasOneRelationGenerator;
use Grazulex\LaravelArc\Generator\Validators\ArrayValidatorGenerator;
use Grazulex\LaravelArc\Generator\Validators\BooleanValidatorGenerator;
use Grazulex\LaravelArc\Generator\Validators\DateTimeValidatorGenerator;
use Grazulex\LaravelArc\Generator\Validators\EnumValidatorGenerator;
use Grazulex\LaravelArc\Generator\Validators\FloatValidatorGenerator;
use Grazulex\LaravelArc\Generator\Validators\IntegerValidatorGenerator;
use Grazulex\LaravelArc\Generator\Validators\StringValidatorGenerator;
use Grazulex\LaravelArc\Generator\Validators\UuidValidatorGenerator;

final class DtoGenerationContext
{
    public function headers(): HeaderGeneratorRegistry
    {
        return new HeaderGeneratorRegistry([
            'dto' => new DtoHeaderGenerator(),
            'model' => new ModelHeaderGenerator(),
            'table' => new TableHeaderGenerator(),
        ]);
    }

    public function fields(): FieldGeneratorRegistry
    {
        return new FieldGeneratorRegistry([
            new StringFieldGenerator(),
            new ArrayFieldGenerator(),
            new BooleanFieldGenerator(),
            new DateFieldGenerator(),
            new DateTimeFieldGenerator(),
            new DecimalFieldGenerator(),
            new EnumFieldGenerator(),
            new FloatFieldGenerator(),
            new IdFieldGenerator(),
            new IntegerFieldGenerator(),
            new JsonFieldGenerator(),
            new TextFieldGenerator(),
            new TimeFieldGenerator(),
            new UuidFieldGenerator(),
        ]);
    }

    public function relations(): RelationGeneratorRegistry
    {
        return new RelationGeneratorRegistry([
            new HasOneRelationGenerator(),
            new HasManyRelationGenerator(),
            new BelongsToRelationGenerator(),
            new BelongsToManyRelationGenerator(),
        ]);
    }

    public function validators(): ValidatorGeneratorRegistry
    {
        return new ValidatorGeneratorRegistry([
            new StringValidatorGenerator(),
            new IntegerValidatorGenerator(),
            new FloatValidatorGenerator(),
            new BooleanValidatorGenerator(),
            new UuidValidatorGenerator(),
            new EnumValidatorGenerator(),
            new DateTimeValidatorGenerator(),
            new ArrayValidatorGenerator(),
        ]);
    }

    public function options(): OptionGeneratorRegistry
    {
        return new OptionGeneratorRegistry([
            new TimestampsOptionGenerator(),
            new SoftDeletesOptionGenerator(),
        ]);
    }
}
